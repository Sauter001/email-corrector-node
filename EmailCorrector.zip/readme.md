# Installation
To execute express.js server, install openAI and express by npm
```
npm i openai express dotenv
```

